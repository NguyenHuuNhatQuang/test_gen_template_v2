#include <bits/stdc++.h>
using namespace std;

#define taskname ""

int main ()
{
    if (fopen (taskname".inp", "r"))
    {
        freopen (taskname".inp", "r", stdin);
        freopen (taskname".out", "w", stdout);
    }
}
